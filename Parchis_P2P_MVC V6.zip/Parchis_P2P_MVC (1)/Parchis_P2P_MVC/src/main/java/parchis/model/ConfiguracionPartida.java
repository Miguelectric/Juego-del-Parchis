/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parchis.model;

/**
 *
 * @author PC
 */
public class ConfiguracionPartida {

    private int maxJugadores;
    private int turnTimeSeconds;
    private boolean allowEatOnExit;
    private boolean allowExitWithFive;

    public ConfiguracionPartida(int maxJugadores, int turnTimeSeconds,
            boolean allowEatOnExit, boolean allowExitWithFive) {
        this.maxJugadores = maxJugadores;
        this.turnTimeSeconds = turnTimeSeconds;
        this.allowEatOnExit = allowEatOnExit;
        this.allowExitWithFive = allowExitWithFive;
    }

    public int getMaxJugadores() {
        return maxJugadores;
    }

    public int getTurnTimeSeconds() {
        return turnTimeSeconds;
    }

    public boolean isAllowEatOnExit() {
        return allowEatOnExit;
    }

    public boolean isAllowExitWithFive() {
        return allowExitWithFive;
    }
}
