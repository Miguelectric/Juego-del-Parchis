package parchis.model;

public class Ficha {
    private int id; // 0, 1, 2, 3
    private int posicion; // -1 = En Casa, 0-51 = Tablero
    private boolean enCasa;
    private boolean enMeta;

    public Ficha(int id) {
        this.id = id;
        this.posicion = -1; // Empieza fuera del tablero
        this.enCasa = true;
        this.enMeta = false;
    }

    public void salirDeCasa(int casillaSalida) {
        this.posicion = casillaSalida;
        this.enCasa = false;
    }

    public void regresarACasa() {
        this.posicion = -1;
        this.enCasa = true;
    }

    public void mover(int pasos) {
        if (!enCasa && !enMeta) {
            this.posicion += pasos;
            if (this.posicion >= 52) {
                // Aquí iría la lógica de entrar al pasillo de color
                // Por ahora, hacemos vuelta circular simple
                this.posicion = this.posicion - 52; 
            }
        }
    }
    // --- ESTE ES EL MÉTODO QUE TE FALTABA ---
    public void coronarMeta() {
        this.enMeta = true;
        // La ficha se queda bloqueada en su posición final
    }

    // Getters
    public int getId() { return id; }
    public int getPosicion() { return posicion; }
    public boolean isEnCasa() { return enCasa; }
    public boolean isEnMeta() { return enMeta; }
}