package parchis.model;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class Jugador {
    private String peerId;
    private String name;
    private String colorName;
    private Color colorObj;
    private String alias; 
    
    // --- NUEVO: ESTADO DE VICTORIA ---
    private boolean enMeta; // True si ya metió las 4 fichas
    
    // --- LÓGICA PARCHÍS ---
    private List<Ficha> fichas;
    private int casillaSalida; 

    // --- LÓGICA BATTLE ROYALE ---
    private int vidas;
    private boolean eliminado;
    
    // --- PUNTOS ---
    private int puntos;

    public Jugador(String peerId, String name, String colorName) {
        this.peerId = peerId;
        this.name = name;
        this.colorName = colorName;
        
        this.vidas = 3; 
        this.eliminado = false;
        this.puntos = 0;
        this.enMeta = false; // Al inicio no ha ganado
        
        this.fichas = new ArrayList<>();
        for(int i=0; i<4; i++) {
            fichas.add(new Ficha(i));
        }
        
        asignarPropiedades(colorName);
    }

    private void asignarPropiedades(String c) {
        switch(c.toUpperCase()) {
            case "BLUE":   this.colorObj = Color.BLUE;   this.alias = "P1"; this.casillaSalida = 0; break;
            case "RED":    this.colorObj = Color.RED;    this.alias = "P2"; this.casillaSalida = 39; break;
            case "GREEN":  this.colorObj = new Color(0, 180, 0); this.alias = "P3"; this.casillaSalida = 13; break;
            case "YELLOW": this.colorObj = Color.ORANGE; this.alias = "P4"; this.casillaSalida = 26; break;
            default:       this.colorObj = Color.BLACK;  this.alias = "??"; this.casillaSalida = 0;
        }
    }

    // --- MÉTODOS DE JUEGO ---
    public void sumarPuntos(int p) {
        this.puntos += p;
    }

    public void perderVida() {
        if (!eliminado) {
            this.vidas--;
            if (this.vidas <= 0) {
                this.eliminado = true;
                // Si muere, todas sus fichas se van a casa
                for(Ficha f : fichas) f.regresarACasa(); 
            }
        }
    }
    
    // --- NUEVO MÉTODO: Checa si las 4 fichas están coronadas ---
    public boolean verificarVictoria() {
        int fichasCoronadas = 0;
        for (Ficha f : fichas) {
            if (f.isEnMeta()) {
                fichasCoronadas++;
            }
        }
        
        // Si las 4 fichas llegaron al final, el jugador gana
        if (fichasCoronadas == 4) {
            this.enMeta = true;
            return true;
        }
        return false;
    }
    

    // --- GETTERS ---
    public int getPuntos() { return puntos; }
    public int getVidas() { return vidas; }
    public boolean isEliminado() { return eliminado; }
    public boolean isEnMeta() { return enMeta; } // Getter para la variable clave
    
    public List<Ficha> getFichas() { return fichas; }
    public int getCasillaSalida() { return casillaSalida; }
    public String getAlias() { return alias; }
    public Color getColorObj() { return colorObj; }
    public String getName() { return name; }
    public String getColorName() { return colorName; }
    public String getPeerId() { return peerId; }
}