/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parchis.model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PC
 */
public class Partida {

    private String id;
    private ConfiguracionPartida config;
    private List<Jugador> jugadores = new ArrayList<>();
    private String hostPeerId;
    private EstadoPartida state;

    public Partida(String id, ConfiguracionPartida config, String hostPeerId) {
        this.id = id;
        this.config = config;
        this.hostPeerId = hostPeerId;
        this.state = EstadoPartida.WAITING_PLAYERS;
    }

    public String getId() {
        return id;
    }

    public ConfiguracionPartida getConfig() {
        return config;
    }

    public String getHostPeerId() {
        return hostPeerId;
    }

    public EstadoPartida getState() {
        return state;
    }

    public void setState(EstadoPartida state) {
        this.state = state;
    }

    public List<Jugador> getJugadores() {
        return jugadores;
    }

    public void addJugador(Jugador jugador) {
        if (jugadores.size() < config.getMaxJugadores()) {
            jugadores.add(jugador);
        }
    }
}
