/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parchis;

import java.util.UUID;
import javax.swing.SwingUtilities;
import parchis.controller.InicioController;
import parchis.network.PeerNetwork;
import parchis.view.*;

/**
 *
 * @author PC
 */
public class App {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            String peerId = "PEER-" + UUID.randomUUID();
            int port = 5000;

            PeerNetwork network = new PeerNetwork(peerId, port);
            network.iniciar();
            
            PantallaInicio inicioView = new PantallaInicio();
            new InicioController(inicioView, network);
            inicioView.setVisible(true);
            
        }); 
    }
}
