package parchis.network;

import parchis.model.ConfiguracionPartida;
import parchis.model.Partida;
import parchis.model.Jugador; // CORREGIDO: modelo -> model

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Collectors;

public class PeerNetwork {

    private final String localId;
    private final int listenPort;
    private final String hostAddress;

    private ServerSocket serverSocket;
    private Thread serverThread;
    
    private volatile Partida hostedGame; 
    private ParsedGameId hostConnectionInfo; 
    
    private Consumer<List<String>> playersUpdateListener;
    private Consumer<String> gameMessageListener;

    public PeerNetwork(String localId, int listenPort) {
        this.localId = localId;
        this.listenPort = listenPort;
        String addr;
        try { addr = InetAddress.getLocalHost().getHostAddress(); } 
        catch (UnknownHostException e) { addr = "localhost"; }
        this.hostAddress = addr;
    }

    public String getLocalId() { return localId; }
    public int getListenPort() { return listenPort; }

    public void setGameMessageListener(Consumer<String> listener) {
        this.gameMessageListener = listener;
    }

    public void iniciar() {
        try {
            serverSocket = new ServerSocket(listenPort);
            serverThread = new Thread(this::acceptLoop, "PeerNetwork-accept");
            serverThread.setDaemon(true);
            serverThread.start();
            System.out.println("PeerNetwork: servidor escuchando en " + hostAddress + ":" + listenPort);
        } catch (IOException e) {
            System.out.println("PeerNetwork: no se pudo abrir el puerto " + listenPort);
        }
    }

    private void acceptLoop() {
        while (serverSocket != null && !serverSocket.isClosed()) {
            try {
                Socket socket = serverSocket.accept();
                Thread t = new Thread(() -> handleClient(socket), "PeerNetwork-client");
                t.setDaemon(true);
                t.start();
            } catch (IOException e) { break; }
        }
    }

    private void handleClient(Socket socket) {
        try (BufferedReader in = new BufferedReader(
                new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8)); 
             BufferedWriter out = new BufferedWriter(
                new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8))) {

            String line = in.readLine();
            if (line == null) return;

            if (line.startsWith("JOIN|")) {
                procesarJoin(line, out, socket);
            } 
            else if (line.startsWith("GAME|")) {
                // 1. Avisar a MI controlador local
                if (gameMessageListener != null) gameMessageListener.accept(line);
                
                // 2. SI SOY HOST, REENVIAR A LOS DEMÁS
                if (hostedGame != null) {
                    broadcastAsHost(line, socket.getInetAddress().getHostAddress());
                }

                out.write("OK|Received\n");
                out.flush();
            } else {
                out.write("ERROR|Comando no soportado\n");
                out.flush();
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try { socket.close(); } catch (IOException ignore) {}
        }
    }

    private void procesarJoin(String line, BufferedWriter out, Socket socket) throws IOException {
        String[] parts = line.split("\\|", 3);
        String baseGameId = parts[1];
        String playerName = parts[2];

        if (hostedGame == null || !hostedGame.getId().equals(baseGameId)) {
            out.write("ERROR|No existe una partida con ese id\n");
            out.flush();
            return;
        }

        synchronized (hostedGame) {
            if (hostedGame.getJugadores().size() >= hostedGame.getConfig().getMaxJugadores()) {
                out.write("ERROR|La partida ya esta llena\n");
                out.flush();
                return;
            }
            String remoteIp = socket.getInetAddress().getHostAddress();
            String remoteId = "REMOTE-" + playerName + "@" + remoteIp + ":" + listenPort; 
            
            // --- CORRECCIÓN DE COLOR ---
            // Asignamos color según el número de jugador (0=Azul, 1=Rojo, etc.)
            int playerIndex = hostedGame.getJugadores().size();
            String colorAsignado = getColorNameByIndex(playerIndex);

            Jugador nuevo = new Jugador(remoteId, playerName, colorAsignado);
            hostedGame.addJugador(nuevo);

            ConfiguracionPartida cfg = hostedGame.getConfig();
            List<String> nombres = hostedGame.getJugadores().stream().map(Jugador::getName).collect(Collectors.toList());
            String jugadoresStr = String.join(",", nombres);

            out.write("OK|" + cfg.getMaxJugadores() + "|" + cfg.getTurnTimeSeconds() + "|" 
                    + cfg.isAllowEatOnExit() + "|" + cfg.isAllowExitWithFive() + "|" + jugadoresStr + "\n");
            out.flush();
            notifyPlayersUpdated(nombres);
        }
    }
    
    public void enviarMensajeJuego(String message) {
        if (hostedGame != null) {
            broadcastAsHost(message, null); 
        } else if (hostConnectionInfo != null) {
            sendMessageToPeer(hostConnectionInfo.host, hostConnectionInfo.port, message);
        }
    }

    private void broadcastAsHost(String message, String ipExclusion) {
        if (hostedGame == null) return;
        for (Jugador j : hostedGame.getJugadores()) {
            if (j.getPeerId().equals(this.localId)) continue; 
            ParsedGameId info = parseSharedId(j.getPeerId());
            if (info != null) {
                if (ipExclusion != null && info.host.equals(ipExclusion)) continue;
                sendMessageToPeer(info.host, info.port, message);
            }
        }
    }

    private void sendMessageToPeer(String host, int port, String message) {
        new Thread(() -> {
            try (Socket s = new Socket(host, port);
                 BufferedWriter out = new BufferedWriter(new OutputStreamWriter(s.getOutputStream(), StandardCharsets.UTF_8));
                 BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8))) {
                out.write(message + "\n");
                out.flush();
                in.readLine(); 
            } catch (IOException e) { System.err.println("Error enviando: " + e.getMessage()); }
        }).start();
    }

    public void setHostedGame(Partida partida) { this.hostedGame = partida; }
    public void setPlayersUpdateListener(Consumer<List<String>> listener) { this.playersUpdateListener = listener; }
    private void notifyPlayersUpdated(List<String> nombres) { if (playersUpdateListener != null) playersUpdateListener.accept(new ArrayList<>(nombres)); }
    public void anunciarPartida(Partida partida) { System.out.println("Hosteando en " + hostAddress + ":" + listenPort); }
    public String crearIdCompartible(String baseGameId) { return baseGameId + "@" + hostAddress + ":" + listenPort; }

    public JoinResult joinGameUsingId(String sharedGameId, String playerName) throws IOException {
        ParsedGameId info = parseSharedId(sharedGameId);
        if (info == null) throw new IllegalArgumentException("Id invalido.");
        this.hostConnectionInfo = info; 

        try (Socket socket = new Socket(info.host, info.port); 
             BufferedWriter out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8)); 
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8))) {

            out.write("JOIN|" + info.baseGameId + "|" + playerName + "\n");
            out.flush();
            String resp = in.readLine();
            if (resp == null || !resp.startsWith("OK|")) throw new IOException("Error: " + resp);

            String[] parts = resp.split("\\|", 6);
            ConfiguracionPartida cfg = new ConfiguracionPartida(Integer.parseInt(parts[1]), Integer.parseInt(parts[2]), Boolean.parseBoolean(parts[3]), Boolean.parseBoolean(parts[4]));
            Partida partida = new Partida(info.baseGameId, cfg, "HOST");
            
            // RECONSTRUIR JUGADORES CON COLORES CORRECTOS
            String[] namesArr = parts[5].split(",");
            List<String> nombres = new ArrayList<>();
            
            int i = 0;
            for(String n : namesArr) {
                if(!n.trim().isEmpty()) { 
                    nombres.add(n.trim()); 
                    // Asignamos color según el orden de la lista
                    String color = getColorNameByIndex(i);
                    partida.addJugador(new Jugador("REMOTE-"+n.trim(), n.trim(), color));
                    i++;
                }
            }
            
            // Agregarme a mí mismo (Si no estoy en la lista aún)
            if(nombres.stream().noneMatch(n -> n.equals(playerName))) {
                String myColor = getColorNameByIndex(i);
                Jugador local = new Jugador(localId, playerName, myColor);
                partida.addJugador(local);
            } else {
                // Si ya estoy en la lista (reconexión rara), buscar cuál soy para retornar el objeto local correcto
                // (Simplificación: Asumimos flujo normal de join)
            }
            
            // Buscamos cuál objeto Jugador soy yo para retornarlo
            Jugador localRef = partida.getJugadores().stream()
                    .filter(j -> j.getName().equals(playerName))
                    .findFirst()
                    .orElse(new Jugador(localId, playerName, "RED")); // Fallback

            return new JoinResult(partida, localRef, sharedGameId, nombres);
        }
    }
    
    // --- NUEVO MÉTODO PARA ASIGNAR COLORES EN ORDEN ---
    private String getColorNameByIndex(int index) {
        // index 0 es el Host (ya es Azul), así que el siguiente que entra es index 1
        switch(index % 4) {
            case 0: return "BLUE";   // P1 (Anfitrión)
            case 1: return "RED";    // P2 (El primer invitado)
            case 2: return "GREEN";  // P3 (El segundo invitado)
            case 3: return "YELLOW"; // P4 (El tercer invitado)
            default: return "BLUE";
        }
    }

    private ParsedGameId parseSharedId(String sharedGameId) {
        if (sharedGameId == null) return null;
        int at = sharedGameId.lastIndexOf('@');
        int colon = sharedGameId.lastIndexOf(':');
        if (at <= 0 || colon <= at) return null;
        try {
            ParsedGameId info = new ParsedGameId();
            info.baseGameId = sharedGameId.substring(0, at);
            info.host = sharedGameId.substring(at + 1, colon);
            info.port = Integer.parseInt(sharedGameId.substring(colon + 1));
            return info;
        } catch (Exception e) { return null; }
    }

    private static class ParsedGameId { String baseGameId; String host; int port; }
    public static class JoinResult {
        private final Partida partida; private final Jugador jugadorLocal; private final String sharedGameId; private final List<String> jugadores;
        public JoinResult(Partida p, Jugador j, String s, List<String> l) { this.partida = p; this.jugadorLocal = j; this.sharedGameId = s; this.jugadores = l; }
        public Partida getPartida() { return partida; }
        public Jugador getJugadorLocal() { return jugadorLocal; }
        public String getSharedGameId() { return sharedGameId; }
        public List<String> getJugadores() { return jugadores; }
    }
}