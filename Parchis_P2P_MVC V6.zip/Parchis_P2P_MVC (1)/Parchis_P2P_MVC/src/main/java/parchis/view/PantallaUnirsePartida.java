/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parchis.view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author zarex
 */
public class PantallaUnirsePartida extends JFrame {

    private JTextField txtPlayerName;
    private JTextField txtGameId;
    private JButton btnUnirse;
    private JButton btnCancelar;

    public PantallaUnirsePartida() {
        setTitle("Unirse a partida");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        buildUi();
        pack();
        setSize(400, 220);
        setLocationRelativeTo(null);
    }

    private void buildUi() {
        JPanel main = new JPanel(new BorderLayout(10, 10));
        main.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
        form.add(new JLabel("Nombre jugador:"));
        txtPlayerName = new JTextField();
        form.add(txtPlayerName);

        form.add(new JLabel("Id de partida:"));
        txtGameId = new JTextField();
        form.add(txtGameId);

        main.add(form, BorderLayout.CENTER);

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnCancelar = new JButton("Cancelar");
        btnUnirse = new JButton("Unirse");
        bottom.add(btnCancelar);
        bottom.add(btnUnirse);

        main.add(bottom, BorderLayout.SOUTH);

        setContentPane(main);
    }

    public String getPlayerName() {
        return txtPlayerName.getText().trim();
    }

    public String getGameId() {
        return txtGameId.getText().trim();
    }

    public void addUnirseListener(ActionListener listener) {
        btnUnirse.addActionListener(listener);
    }

    public void addCancelarListener(ActionListener listener) {
        btnCancelar.addActionListener(listener);
    }

    public void showMessage(String message) {
        JOptionPane.showMessageDialog(this, message);
    }

    public void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error",
                JOptionPane.ERROR_MESSAGE);
    }
}
