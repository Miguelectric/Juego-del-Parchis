/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parchis.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

/**
 *
 * @author PC
 */
public class PantallaConfigurarPartida extends JFrame {

    private JTextField txtPlayerName;
    private JComboBox<Integer> comboPlayers;
    private JSpinner spinnerTurnTime;
    private JCheckBox chkEatOnExit;
    private JCheckBox chkExitWithFive;
    private JButton btnCreateMatch;

    public PantallaConfigurarPartida() {
        setTitle("Configurar partida Parchis");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        buildUi();
        pack();
        setLocationRelativeTo(null);
    }

    private void buildUi() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));

        form.add(new JLabel("Nombre jugador:"));
        txtPlayerName = new JTextField();
        form.add(txtPlayerName);

        form.add(new JLabel("Numero de jugadores:"));
        comboPlayers = new JComboBox<>(new Integer[]{2, 3, 4});
        comboPlayers.setSelectedIndex(0);
        form.add(comboPlayers);

        form.add(new JLabel("Tiempo por turno (segundos):"));
        spinnerTurnTime = new JSpinner(new SpinnerNumberModel(30, 10, 300, 5));
        form.add(spinnerTurnTime);

        form.add(new JLabel("Permitir comer en salida:"));
        chkEatOnExit = new JCheckBox();
        chkEatOnExit.setSelected(true);
        form.add(chkEatOnExit);

        form.add(new JLabel("Permitir salir con cinco:"));
        chkExitWithFive = new JCheckBox();
        chkExitWithFive.setSelected(true);
        form.add(chkExitWithFive);

        panel.add(form, BorderLayout.CENTER);

        btnCreateMatch = new JButton("Crear partida");
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottom.add(btnCreateMatch);
        panel.add(bottom, BorderLayout.SOUTH);

        setContentPane(panel);
    }

    public String getPlayerName() {
        return txtPlayerName.getText().trim();
    }

    public int getMaxPlayers() {
        Integer value = (Integer) comboPlayers.getSelectedItem();
        return value != null ? value : 2;
    }

    public int getTurnTimeSeconds() {
        Object value = spinnerTurnTime.getValue();
        if (value instanceof Integer) {
            return (Integer) value;
        }
        return 30;
    }

    public boolean isEatOnExitEnabled() {
        return chkEatOnExit.isSelected();
    }

    public boolean isExitWithFiveEnabled() {
        return chkExitWithFive.isSelected();
    }

    public void addCreateMatchListener(ActionListener listener) {
        btnCreateMatch.addActionListener(listener);
    }

    public void showMessage(String message) {
        JOptionPane.showMessageDialog(this, message);
    }

    public void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error",
                JOptionPane.ERROR_MESSAGE);
    }
}
