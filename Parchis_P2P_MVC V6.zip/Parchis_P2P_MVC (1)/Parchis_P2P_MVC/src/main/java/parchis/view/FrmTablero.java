package parchis.view;

import parchis.model.Jugador;
import parchis.model.Partida;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class FrmTablero extends JFrame {

    private JLabel lblFondo; // Aquí irá tu imagen de tablero
    private JPanel panelAbsoluto; // Panel con layout null para mover cosas libremente
    
    // EL ARREGLO DE CASILLAS (Tus JTextFields)
    // casillas[0] es la salida del rojo, casillas[1] la siguiente, etc.
    private JTextField[] casillas; 
    
    private JButton btnDado;
    private JLabel lblEstado;

    public FrmTablero(Partida partida, Jugador local) {
        setTitle("Parchís - Vista JTextField - Jugador: " + local.getName());
        setSize(800, 850); // Ajusta al tamaño de tu imagen
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // 1. Panel principal con Layout Absoluto (Para encimar cosas)
        panelAbsoluto = new JPanel();
        panelAbsoluto.setLayout(null); 
        setContentPane(panelAbsoluto);

        // 2. Controles (Dado y Estado)
        lblEstado = new JLabel("Esperando...");
        lblEstado.setBounds(20, 10, 400, 30);
        lblEstado.setFont(new Font("Arial", Font.BOLD, 14));
        panelAbsoluto.add(lblEstado);

        btnDado = new JButton("TIRAR DADO");
        btnDado.setBounds(600, 10, 150, 30);
        btnDado.setEnabled(false);
        panelAbsoluto.add(btnDado);

        // 3. INICIALIZAR LAS CASILLAS (JTextFields)
        // Aquí simulamos 68 casillas. 
        // EN TU DISEÑO: Tú acomodarás estos textfields sobre los cuadritos de tu imagen.
        casillas = new JTextField[68];
        inicializarCasillasManuales(); 

        // 4. CARGAR IMAGEN DE FONDO
        // Asegúrate de tener una imagen "tablero.jpg" en tu proyecto o cambia la ruta
        ImageIcon icono = new ImageIcon(getClass().getResource("/tablero.jpg")); 
        // Si no tienes imagen aún, esto evita error y pone un color de fondo
        if (icono.getImageLoadStatus() != MediaTracker.COMPLETE) {
            panelAbsoluto.setBackground(Color.WHITE);
        }
        
        lblFondo = new JLabel();
        lblFondo.setIcon(icono);
        lblFondo.setBounds(0, 50, 800, 800); // Ajusta posición y tamaño
        panelAbsoluto.add(lblFondo); // Se agrega AL FINAL para quedar al fondo (Swing Z-order)
    }

    // --- MÉTODOS PARA EL CONTROLADOR ---

    // Este método recibe el ID lógico (ej: 5) y pone el número del jugador ahí
    public void actualizarCasilla(int indexId, String textoJugador) {
        if (indexId >= 0 && indexId < casillas.length) {
            // Limpiamos o concatenamos. 
            // Si quieres que se vea solo el último:
            casillas[indexId].setText(textoJugador);
            
            // Opcional: Cambiar color de fondo para resaltar
            casillas[indexId].setBackground(Color.CYAN);
        }
    }

    // Borra el texto de una casilla (cuando la ficha se va)
    public void limpiarCasilla(int indexId) {
        if (indexId >= 0 && indexId < casillas.length) {
            casillas[indexId].setText("");
            casillas[indexId].setBackground(null); // Quitar color
            casillas[indexId].setOpaque(false);    // Volver transparente
        }
    }

    public JButton getBtnDado() { return btnDado; }
    public void setEstado(String t) { lblEstado.setText(t); }

    // --- CONFIGURACIÓN VISUAL ---
    
    private void inicializarCasillasManuales() {
        // Como ejemplo, creo un círculo de JTextFields.
        // TÚ DEBES HACER ESTO EN NETBEANS ARRASTRANDO Y SOLTANDO,
        // Y LUEGO ASIGNÁNDOLOS AL ARRAY: casillas[0] = jTextField1; casillas[1] = jTextField2;
        
        int radio = 300;
        int centroX = 380;
        int centroY = 400;

        for (int i = 0; i < 68; i++) {
            casillas[i] = new JTextField();
            
            // Cálculo matemático para hacer un círculo (Solo para ejemplo)
            double angulo = 2 * Math.PI * i / 68;
            int x = (int) (centroX + radio * Math.cos(angulo));
            int y = (int) (centroY + radio * Math.sin(angulo));

            // Configurar estilo del JTextField para que parezca ficha
            casillas[i].setBounds(x, y, 30, 30);
            casillas[i].setHorizontalAlignment(JTextField.CENTER);
            casillas[i].setEditable(false);
            casillas[i].setBorder(BorderFactory.createLineBorder(Color.BLACK)); // Borde negro
            casillas[i].setOpaque(false); // Transparente para ver la imagen de fondo
            casillas[i].setFont(new Font("Arial", Font.BOLD, 12));

            panelAbsoluto.add(casillas[i]);
        }
    }
    
    // Si usas NetBeans Designer, usa un método así para vincularlos:
    /*
    private void vincularComponentesNetBeans() {
        casillas[0] = jTextField1; // El que pusiste en la salida roja
        casillas[1] = jTextField2;
        // ... así hasta el 67
    }
    */
}