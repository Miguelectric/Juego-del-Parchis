/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package parchis.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.TextField;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import parchis.model.Jugador;

/**
 *
 * @author yahir
 */
public class TableroParchis extends javax.swing.JFrame {
    
private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(TableroParchis.class.getName());
   // --- NUEVO: Array para controlar las casillas en orden ---
// --- LÓGICA DE 4 JUGADORES ---
    // Arrays para los caminos centrales (META)
    private JTextField[] pasilloAzul;
    private JTextField[] pasilloRojo;
    private JTextField[] pasilloVerde;
    private JTextField[] pasilloAmarillo;
    private JTextField[] casillas;
    // --- NUEVO: Variable para controlar donde está el jugador ---
  private javax.swing.JLabel[] camposVidas;
    public TableroParchis() {
        initComponents();
        inicializarPasillos();
    // Estilo del botón
        jButton1.setBackground(new Color(50, 50, 50));
        jButton1.setForeground(Color.WHITE);
        jButton1.setFont(new Font("Segoe UI", Font.BOLD, 16));
        jButton1.setFocusPainted(false);
        
        inicializarMapaVisual();
        inicializarVidasVisual();
    }
    private void configurarEstiloPasillo(JTextField[] p) {
        for(JTextField t : p) {
            if(t!=null) {
                t.setEditable(false); 
                t.setHorizontalAlignment(SwingConstants.CENTER);
                t.setBorder(null);
                t.setOpaque(false);
                t.setBackground(new Color(0,0,0,0));
                t.setFont(new Font("Arial", Font.BOLD, 10));
            }
        }
    }
    private void limpiarPasilloArray(javax.swing.JTextField[] pasillo) {
        if (pasillo != null) {
            for (javax.swing.JTextField casilla : pasillo) {
                if (casilla != null) {
                    casilla.setOpaque(false);
                    casilla.setText("");
                    casilla.setBorder(null);
                    casilla.setBackground(new java.awt.Color(0,0,0,0));
                }
            }
        }
    }
   // Método público que el controlador llamará para borrar TODO
    public void limpiarTodo() {
        // 1. Limpiar el tablero normal (0-51)
        for(int i=0; i<52; i++) {
            limpiarCasilla(i);
        }
        
        // 2. Limpiar los 4 pasillos de meta
        limpiarPasilloArray(pasilloAzul);
        limpiarPasilloArray(pasilloRojo);
        limpiarPasilloArray(pasilloVerde);
        limpiarPasilloArray(pasilloAmarillo);
    }
   private void inicializarPasillos() {
        // --- AQUÍ CONECTAMOS LA LÓGICA CON TUS VARIABLES DEL DISEÑO ---
        
        // PASILLO AZUL (Player 1)
        // Orden: Desde la entrada (arriba) hasta el centro (meta)
        pasilloAzul = new JTextField[] {
            pasilloazul1, pasilloazul2, pasilloazul3, pasilloazul4, pasilloazul5
        };
        
        // PASILLO ROJO (Player 2)
        // Orden: Desde la entrada (abajo) hasta el centro
        pasilloRojo = new JTextField[] {
            pasillorojo1, pasillorojo2, pasillorojo3, pasillorojo4, pasillorojo5
        };
        
        // PASILLO VERDE (Player 3)
        // Orden: Desde la entrada (derecha) hasta el centro
        pasilloVerde = new JTextField[] {
            pasilloverde1, pasilloverde2, pasilloverde3, pasilloverde4, pasilloverde5
        };
        
        // PASILLO AMARILLO (Player 4)
        // Orden: Desde la entrada (izquierda) hasta el centro
        pasilloAmarillo = new JTextField[] {
            pasilloamarillo1, pasilloamarillo2, pasilloamarillo3, pasilloamarillo4, pasilloamarillo5
        };
        
        // Configuramos para que sean invisibles hasta que llegue una ficha
        configurarEstiloPasillo(pasilloAzul);
        configurarEstiloPasillo(pasilloRojo);
        configurarEstiloPasillo(pasilloVerde);
        configurarEstiloPasillo(pasilloAmarillo);
    }
    private void inicializarVidasVisual() {
        camposVidas = new JLabel[] { player1Vida, player2Vida, player3Vida, player4Vida };
        for (JLabel campo : camposVidas) {
            if (campo != null) {
                campo.setHorizontalAlignment(SwingConstants.CENTER); campo.setText(""); campo.setOpaque(true);
            }
        }
    }
// Método para meter tus 52 campos en el array
    // ASUMIENDO: 
    // - jTextField1 es la casilla de salida del Azul (Posición lógica 0)
    // - jTextField2 es la siguiente...
    // - jTextField52 es la última casilla antes de dar la vuelta completa
    private void inicializarMapaVisual() {
        casillas = new JTextField[] {
            jTextField1, jTextField2, jTextField3, jTextField4, jTextField5, jTextField6, jTextField7, jTextField8, jTextField9, jTextField10,
            jTextField11, jTextField12, jTextField13, jTextField14, jTextField15, jTextField16, jTextField17, jTextField18, jTextField19, jTextField20,
            jTextField21, jTextField22, jTextField23, jTextField24, jTextField25, jTextField26, jTextField27, jTextField28, jTextField29, jTextField30,
            jTextField31, jTextField32, jTextField33, jTextField34, jTextField35, jTextField36, jTextField37, jTextField38, jTextField39, jTextField40,
            jTextField41, jTextField42, jTextField43, jTextField44, jTextField45, jTextField46, jTextField47, jTextField48, jTextField49, jTextField50,
            jTextField51, jTextField52
        };
        for (JTextField txt : casillas) {
            if(txt != null) { 
                txt.setEditable(false); txt.setHorizontalAlignment(SwingConstants.CENTER); txt.setBorder(null); 
                txt.setOpaque(false); txt.setBackground(new Color(0,0,0,0)); txt.setFont(new Font("Segoe UI", Font.BOLD, 12)); txt.setText(""); 
            }
        }
    }
 // --- MÉTODOS PARA EL CONTROLADOR ---

    public void pintarFicha(int pos, java.awt.Color color, String alias) {
        JTextField casillaPintar = null;

        // TABLERO NORMAL (0 a 51)
        if (pos >= 0 && pos < 52) {
            casillaPintar = casillas[pos];
        } 
        // PASILLO AZUL (Empieza en 100)
        else if (pos >= 100 && pos < 105) { 
            int idx = pos - 100; // 100 se convierte en array[0]
            if (pasilloAzul != null && idx < pasilloAzul.length) {
                casillaPintar = pasilloAzul[idx];
            }
        }
        // PASILLO ROJO (Empieza en 200)
        else if (pos >= 200 && pos < 205) { 
            int idx = pos - 200;
            if (pasilloRojo != null && idx < pasilloRojo.length) {
                casillaPintar = pasilloRojo[idx];
            }
        }
        // PASILLO VERDE (Empieza en 300)
        else if (pos >= 300 && pos < 305) { 
            int idx = pos - 300;
            if (pasilloVerde != null && idx < pasilloVerde.length) {
                casillaPintar = pasilloVerde[idx];
            }
        }
        // PASILLO AMARILLO (Empieza en 400)
        else if (pos >= 400 && pos < 405) { 
            int idx = pos - 400;
            if (pasilloAmarillo != null && idx < pasilloAmarillo.length) {
                casillaPintar = pasilloAmarillo[idx];
            }
        }

        // PINTAR SI ENCONTRAMOS LA CASILLA
        if (casillaPintar != null) {
            casillaPintar.setOpaque(true);
            casillaPintar.setBackground(color);
            casillaPintar.setForeground(java.awt.Color.WHITE);
            casillaPintar.setText(alias);
            casillaPintar.setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.WHITE, 2));
        }
    }

    public void limpiarCasilla(int pos) {
        if (pos >= 0 && pos < casillas.length) {
            JTextField casilla = casillas[pos];
            
            // Volver a modo invisible
            casilla.setOpaque(false);
            casilla.setBackground(new Color(0,0,0,0));
            casilla.setText("");
            
            // Quitar el borde
            casilla.setBorder(null);
        }
    }

    public void setEstado(String texto) {
        // Usamos tu jLabel2 para mostrar estado
        jLabel2.setText(texto);
        jLabel2.setOpaque(false); // Transparente
        jLabel2.setForeground(new Color(0,0,0, 200)); // Negro semitransparente
        jLabel2.setFont(new Font("Arial", Font.BOLD, 18));
    }

    // Exponer el botón para que el Controller le ponga el ActionListener
    
    public JButton getBtnAccion() {
        return jButton1;
    }
   public void actualizarVidas(java.util.List<parchis.model.Jugador> jugadores) {
        if (camposVidas == null || jugadores == null) return;
        for (int i = 0; i < 4; i++) {
            if (camposVidas[i] == null) continue;
            if (i < jugadores.size()) {
                parchis.model.Jugador j = jugadores.get(i);
                camposVidas[i].setText(j.getVidas() + " ♥ | Pts: " + j.getPuntos()); // Muestra Vidas y Puntos
                if (j.isEliminado()) {
                    camposVidas[i].setBackground(Color.BLACK); camposVidas[i].setForeground(Color.GRAY);
                } else {
                    camposVidas[i].setBackground(Color.WHITE); camposVidas[i].setForeground(Color.BLACK);
                }
            } else {
                camposVidas[i].setText(""); camposVidas[i].setBackground(null);
            }
        }
    }
 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jTextField9 = new javax.swing.JTextField();
        jTextField10 = new javax.swing.JTextField();
        jTextField11 = new javax.swing.JTextField();
        jTextField12 = new javax.swing.JTextField();
        jTextField13 = new javax.swing.JTextField();
        jTextField14 = new javax.swing.JTextField();
        jTextField15 = new javax.swing.JTextField();
        jTextField16 = new javax.swing.JTextField();
        jTextField17 = new javax.swing.JTextField();
        jTextField18 = new javax.swing.JTextField();
        jTextField19 = new javax.swing.JTextField();
        jTextField20 = new javax.swing.JTextField();
        jTextField21 = new javax.swing.JTextField();
        jTextField22 = new javax.swing.JTextField();
        jTextField23 = new javax.swing.JTextField();
        jTextField24 = new javax.swing.JTextField();
        jTextField25 = new javax.swing.JTextField();
        jTextField26 = new javax.swing.JTextField();
        jTextField27 = new javax.swing.JTextField();
        jTextField28 = new javax.swing.JTextField();
        jTextField29 = new javax.swing.JTextField();
        jTextField30 = new javax.swing.JTextField();
        jTextField31 = new javax.swing.JTextField();
        jTextField32 = new javax.swing.JTextField();
        jTextField33 = new javax.swing.JTextField();
        jTextField34 = new javax.swing.JTextField();
        jTextField35 = new javax.swing.JTextField();
        jTextField36 = new javax.swing.JTextField();
        jTextField37 = new javax.swing.JTextField();
        jTextField38 = new javax.swing.JTextField();
        pasillorojo1 = new javax.swing.JTextField();
        jTextField40 = new javax.swing.JTextField();
        jTextField41 = new javax.swing.JTextField();
        jTextField42 = new javax.swing.JTextField();
        jTextField43 = new javax.swing.JTextField();
        jTextField44 = new javax.swing.JTextField();
        jTextField45 = new javax.swing.JTextField();
        jTextField46 = new javax.swing.JTextField();
        jTextField47 = new javax.swing.JTextField();
        jTextField48 = new javax.swing.JTextField();
        jTextField49 = new javax.swing.JTextField();
        jTextField50 = new javax.swing.JTextField();
        jTextField51 = new javax.swing.JTextField();
        jTextField52 = new javax.swing.JTextField();
        pasilloazul1 = new javax.swing.JTextField();
        pasilloazul2 = new javax.swing.JTextField();
        pasilloazul3 = new javax.swing.JTextField();
        pasilloazul4 = new javax.swing.JTextField();
        pasilloazul5 = new javax.swing.JTextField();
        pasilloverde2 = new javax.swing.JTextField();
        pasilloverde1 = new javax.swing.JTextField();
        pasilloverde5 = new javax.swing.JTextField();
        pasilloverde4 = new javax.swing.JTextField();
        pasilloverde3 = new javax.swing.JTextField();
        jTextField39 = new javax.swing.JTextField();
        pasillorojo2 = new javax.swing.JTextField();
        pasillorojo3 = new javax.swing.JTextField();
        pasillorojo4 = new javax.swing.JTextField();
        pasillorojo5 = new javax.swing.JTextField();
        pasilloamarillo1 = new javax.swing.JTextField();
        pasilloamarillo2 = new javax.swing.JTextField();
        pasilloamarillo3 = new javax.swing.JTextField();
        pasilloamarillo4 = new javax.swing.JTextField();
        pasilloamarillo5 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        player1Vida = new javax.swing.JLabel();
        player4Vida = new javax.swing.JLabel();
        player3Vida = new javax.swing.JLabel();
        player2Vida = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 300, 30, 20));

        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 300, 30, 20));
        jPanel1.add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 300, 30, 20));
        jPanel1.add(jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 300, 30, 20));
        jPanel1.add(jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 300, 30, -1));

        jTextField6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField6ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 300, 30, -1));
        jPanel1.add(jTextField7, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 270, 30, 20));
        jPanel1.add(jTextField8, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 228, 30, -1));
        jPanel1.add(jTextField9, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 190, 30, 20));

        jTextField10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField10ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField10, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 150, 30, -1));

        jTextField11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField11ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField11, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 120, 30, 20));

        jTextField12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField12ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField12, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 80, 30, 20));

        jTextField13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField13ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField13, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 80, 20, 20));

        jTextField14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField14ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField14, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 80, 30, 20));

        jTextField15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField15ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField15, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 120, 30, 20));

        jTextField16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField16ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField16, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 150, 30, 20));

        jTextField17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField17ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField17, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 190, 30, 20));

        jTextField18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField18ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField18, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 230, 30, 20));

        jTextField19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField19ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField19, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 270, 30, 20));

        jTextField20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField20ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField20, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 300, 30, 20));

        jTextField21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField21ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField21, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 300, 30, 20));

        jTextField22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField22ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField22, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 300, 30, 20));

        jTextField23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField23ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField23, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 300, 30, 20));

        jTextField24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField24ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField24, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 300, 30, 20));

        jTextField25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField25ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField25, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 300, 30, 20));

        jTextField26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField26ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField26, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 340, 30, 20));

        jTextField27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField27ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField27, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 370, 30, 20));

        jTextField28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField28ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField28, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 370, 30, 20));

        jTextField29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField29ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField29, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 370, 30, 20));

        jTextField30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField30ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField30, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 370, 30, 20));

        jTextField31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField31ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField31, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 370, 30, 20));

        jTextField32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField32ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField32, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 370, 30, 20));

        jTextField33.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField33ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField33, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 410, 30, 20));

        jTextField34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField34ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField34, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 450, 30, 20));

        jTextField35.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField35ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField35, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 490, 30, 20));

        jTextField36.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField36ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField36, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 520, 30, 20));

        jTextField37.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField37ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField37, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 560, 30, 20));

        jTextField38.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField38ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField38, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 600, 30, 20));

        pasillorojo1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasillorojo1ActionPerformed(evt);
            }
        });
        jPanel1.add(pasillorojo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 560, 30, 20));

        jTextField40.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField40ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField40, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 600, 30, 20));

        jTextField41.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField41ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField41, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 560, 30, 20));

        jTextField42.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField42ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField42, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 530, 30, 20));

        jTextField43.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField43ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField43, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 490, 30, 20));

        jTextField44.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField44ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField44, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 450, 30, 20));

        jTextField45.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField45ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField45, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 420, 30, 20));

        jTextField46.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField46ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField46, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 380, 30, 20));

        jTextField47.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField47ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField47, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 380, 30, 20));

        jTextField48.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField48ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField48, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 380, 30, 20));

        jTextField49.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField49ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField49, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 380, 30, 20));

        jTextField50.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField50ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField50, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 380, 30, 20));

        jTextField51.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField51ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField51, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 380, 30, 20));

        jTextField52.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField52ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField52, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 340, 30, 20));

        pasilloazul1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasilloazul1ActionPerformed(evt);
            }
        });
        jPanel1.add(pasilloazul1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 340, 30, 20));

        pasilloazul2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasilloazul2ActionPerformed(evt);
            }
        });
        jPanel1.add(pasilloazul2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 340, 30, 20));

        pasilloazul3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasilloazul3ActionPerformed(evt);
            }
        });
        jPanel1.add(pasilloazul3, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 340, 30, 20));

        pasilloazul4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasilloazul4ActionPerformed(evt);
            }
        });
        jPanel1.add(pasilloazul4, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 340, 30, 20));

        pasilloazul5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasilloazul5ActionPerformed(evt);
            }
        });
        jPanel1.add(pasilloazul5, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 340, 30, 20));

        pasilloverde2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasilloverde2ActionPerformed(evt);
            }
        });
        jPanel1.add(pasilloverde2, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 340, 30, 20));

        pasilloverde1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasilloverde1ActionPerformed(evt);
            }
        });
        jPanel1.add(pasilloverde1, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 340, 30, 20));

        pasilloverde5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasilloverde5ActionPerformed(evt);
            }
        });
        jPanel1.add(pasilloverde5, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 340, 30, 20));

        pasilloverde4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasilloverde4ActionPerformed(evt);
            }
        });
        jPanel1.add(pasilloverde4, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 340, 30, 20));

        pasilloverde3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasilloverde3ActionPerformed(evt);
            }
        });
        jPanel1.add(pasilloverde3, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 340, 30, 20));

        jTextField39.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField39ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField39, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 600, 30, 20));

        pasillorojo2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasillorojo2ActionPerformed(evt);
            }
        });
        jPanel1.add(pasillorojo2, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 520, 30, 20));

        pasillorojo3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasillorojo3ActionPerformed(evt);
            }
        });
        jPanel1.add(pasillorojo3, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 490, 30, 20));

        pasillorojo4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasillorojo4ActionPerformed(evt);
            }
        });
        jPanel1.add(pasillorojo4, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 450, 30, 20));

        pasillorojo5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasillorojo5ActionPerformed(evt);
            }
        });
        jPanel1.add(pasillorojo5, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 420, 30, 20));

        pasilloamarillo1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasilloamarillo1ActionPerformed(evt);
            }
        });
        jPanel1.add(pasilloamarillo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 120, 30, 20));

        pasilloamarillo2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasilloamarillo2ActionPerformed(evt);
            }
        });
        jPanel1.add(pasilloamarillo2, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 150, 30, 20));

        pasilloamarillo3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasilloamarillo3ActionPerformed(evt);
            }
        });
        jPanel1.add(pasilloamarillo3, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 190, 30, 20));

        pasilloamarillo4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasilloamarillo4ActionPerformed(evt);
            }
        });
        jPanel1.add(pasilloamarillo4, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 230, 30, 20));

        pasilloamarillo5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasilloamarillo5ActionPerformed(evt);
            }
        });
        jPanel1.add(pasilloamarillo5, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 260, 30, 20));

        jButton1.setText("Turno");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 0, 210, -1));

        player1Vida.setText("Player1");
        jPanel1.add(player1Vida, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 80, -1, -1));

        player4Vida.setText("Player4");
        jPanel1.add(player4Vida, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 80, -1, -1));

        player3Vida.setText("Player3");
        jPanel1.add(player3Vida, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 600, -1, -1));

        player2Vida.setText("Player2");
        jPanel1.add(player2Vida, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 610, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\yahir\\Downloads\\Parchis_P2P_MVC (1)\\Parchis_P2P_MVC\\src\\main\\java\\resources\\c9668e67-9fd9-4f4f-8e3c-e99125e29e22.jpg")); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 820, 620));

        jLabel2.setText("JUGADOR");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 0, 290, 40));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void jTextField6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField6ActionPerformed

    private void jTextField10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField10ActionPerformed

    private void jTextField11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField11ActionPerformed

    private void jTextField12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField12ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField12ActionPerformed

    private void jTextField13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField13ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField13ActionPerformed

    private void jTextField14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField14ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField14ActionPerformed

    private void jTextField15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField15ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField15ActionPerformed

    private void jTextField16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField16ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField16ActionPerformed

    private void jTextField17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField17ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField17ActionPerformed

    private void jTextField18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField18ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField18ActionPerformed

    private void jTextField19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField19ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField19ActionPerformed

    private void jTextField20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField20ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField20ActionPerformed

    private void jTextField21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField21ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField21ActionPerformed

    private void jTextField22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField22ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField22ActionPerformed

    private void jTextField23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField23ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField23ActionPerformed

    private void jTextField24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField24ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField24ActionPerformed

    private void jTextField25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField25ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField25ActionPerformed

    private void jTextField26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField26ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField26ActionPerformed

    private void jTextField27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField27ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField27ActionPerformed

    private void jTextField28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField28ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField28ActionPerformed

    private void jTextField29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField29ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField29ActionPerformed

    private void jTextField30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField30ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField30ActionPerformed

    private void jTextField31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField31ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField31ActionPerformed

    private void jTextField32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField32ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField32ActionPerformed

    private void jTextField33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField33ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField33ActionPerformed

    private void jTextField34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField34ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField34ActionPerformed

    private void jTextField35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField35ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField35ActionPerformed

    private void jTextField36ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField36ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField36ActionPerformed

    private void jTextField37ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField37ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField37ActionPerformed

    private void jTextField38ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField38ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField38ActionPerformed

    private void pasillorojo1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasillorojo1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pasillorojo1ActionPerformed

    private void jTextField40ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField40ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField40ActionPerformed

    private void jTextField41ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField41ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField41ActionPerformed

    private void jTextField42ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField42ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField42ActionPerformed

    private void jTextField43ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField43ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField43ActionPerformed

    private void jTextField44ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField44ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField44ActionPerformed

    private void jTextField45ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField45ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField45ActionPerformed

    private void jTextField46ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField46ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField46ActionPerformed

    private void jTextField47ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField47ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField47ActionPerformed

    private void jTextField48ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField48ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField48ActionPerformed

    private void jTextField49ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField49ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField49ActionPerformed

    private void jTextField50ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField50ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField50ActionPerformed

    private void jTextField51ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField51ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField51ActionPerformed

    private void jTextField52ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField52ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField52ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
      
    }//GEN-LAST:event_jButton1ActionPerformed

    private void pasilloazul1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasilloazul1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pasilloazul1ActionPerformed

    private void pasilloazul2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasilloazul2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pasilloazul2ActionPerformed

    private void pasilloazul3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasilloazul3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pasilloazul3ActionPerformed

    private void pasilloazul4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasilloazul4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pasilloazul4ActionPerformed

    private void pasilloazul5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasilloazul5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pasilloazul5ActionPerformed

    private void pasilloverde2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasilloverde2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pasilloverde2ActionPerformed

    private void pasilloverde1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasilloverde1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pasilloverde1ActionPerformed

    private void pasilloverde5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasilloverde5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pasilloverde5ActionPerformed

    private void pasilloverde4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasilloverde4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pasilloverde4ActionPerformed

    private void pasilloverde3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasilloverde3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pasilloverde3ActionPerformed

    private void jTextField39ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField39ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField39ActionPerformed

    private void pasillorojo2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasillorojo2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pasillorojo2ActionPerformed

    private void pasillorojo3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasillorojo3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pasillorojo3ActionPerformed

    private void pasillorojo4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasillorojo4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pasillorojo4ActionPerformed

    private void pasillorojo5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasillorojo5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pasillorojo5ActionPerformed

    private void pasilloamarillo1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasilloamarillo1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pasilloamarillo1ActionPerformed

    private void pasilloamarillo2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasilloamarillo2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pasilloamarillo2ActionPerformed

    private void pasilloamarillo3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasilloamarillo3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pasilloamarillo3ActionPerformed

    private void pasilloamarillo4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasilloamarillo4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pasilloamarillo4ActionPerformed

    private void pasilloamarillo5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasilloamarillo5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pasilloamarillo5ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
      try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(() -> new TableroParchis().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField14;
    private javax.swing.JTextField jTextField15;
    private javax.swing.JTextField jTextField16;
    private javax.swing.JTextField jTextField17;
    private javax.swing.JTextField jTextField18;
    private javax.swing.JTextField jTextField19;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField20;
    private javax.swing.JTextField jTextField21;
    private javax.swing.JTextField jTextField22;
    private javax.swing.JTextField jTextField23;
    private javax.swing.JTextField jTextField24;
    private javax.swing.JTextField jTextField25;
    private javax.swing.JTextField jTextField26;
    private javax.swing.JTextField jTextField27;
    private javax.swing.JTextField jTextField28;
    private javax.swing.JTextField jTextField29;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField30;
    private javax.swing.JTextField jTextField31;
    private javax.swing.JTextField jTextField32;
    private javax.swing.JTextField jTextField33;
    private javax.swing.JTextField jTextField34;
    private javax.swing.JTextField jTextField35;
    private javax.swing.JTextField jTextField36;
    private javax.swing.JTextField jTextField37;
    private javax.swing.JTextField jTextField38;
    private javax.swing.JTextField jTextField39;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField40;
    private javax.swing.JTextField jTextField41;
    private javax.swing.JTextField jTextField42;
    private javax.swing.JTextField jTextField43;
    private javax.swing.JTextField jTextField44;
    private javax.swing.JTextField jTextField45;
    private javax.swing.JTextField jTextField46;
    private javax.swing.JTextField jTextField47;
    private javax.swing.JTextField jTextField48;
    private javax.swing.JTextField jTextField49;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField50;
    private javax.swing.JTextField jTextField51;
    private javax.swing.JTextField jTextField52;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    private javax.swing.JTextField pasilloamarillo1;
    private javax.swing.JTextField pasilloamarillo2;
    private javax.swing.JTextField pasilloamarillo3;
    private javax.swing.JTextField pasilloamarillo4;
    private javax.swing.JTextField pasilloamarillo5;
    private javax.swing.JTextField pasilloazul1;
    private javax.swing.JTextField pasilloazul2;
    private javax.swing.JTextField pasilloazul3;
    private javax.swing.JTextField pasilloazul4;
    private javax.swing.JTextField pasilloazul5;
    private javax.swing.JTextField pasillorojo1;
    private javax.swing.JTextField pasillorojo2;
    private javax.swing.JTextField pasillorojo3;
    private javax.swing.JTextField pasillorojo4;
    private javax.swing.JTextField pasillorojo5;
    private javax.swing.JTextField pasilloverde1;
    private javax.swing.JTextField pasilloverde2;
    private javax.swing.JTextField pasilloverde3;
    private javax.swing.JTextField pasilloverde4;
    private javax.swing.JTextField pasilloverde5;
    private javax.swing.JLabel player1Vida;
    private javax.swing.JLabel player2Vida;
    private javax.swing.JLabel player3Vida;
    private javax.swing.JLabel player4Vida;
    // End of variables declaration//GEN-END:variables
}
