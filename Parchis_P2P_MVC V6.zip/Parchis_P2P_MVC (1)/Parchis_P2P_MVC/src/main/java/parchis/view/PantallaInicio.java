/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parchis.view;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/**
 *
 * @author PC
 */
public class PantallaInicio extends JFrame {

    private JButton btnConfigurarPartida;
    private JButton btnUnirsePartida;
    private JButton btnSalir;
    private JButton BtnTableroPrueba;

    public PantallaInicio() {
        setTitle("Menu Parchis");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        buildUi();
        pack();
        setSize(500, 350);
        setLocationRelativeTo(null);
    }

    private void buildUi() {
        JPanel main = new JPanel();
        main.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        main.setLayout(new BorderLayout(10, 10));

        JLabel title = new JLabel("Parchis Online", SwingConstants.CENTER);
        title.setFont(title.getFont().deriveFont(Font.BOLD, 22f));
        main.add(title, BorderLayout.NORTH);

        JPanel buttonsPanel = new JPanel();
        buttonsPanel.setLayout(new GridLayout(0, 1, 10, 10));

        btnConfigurarPartida = new JButton("Configurar partida");
        btnUnirsePartida = new JButton("Unirse a partida");
        btnSalir = new JButton("Salir");
        BtnTableroPrueba = new JButton("Prueba Tablero");

        buttonsPanel.add(BtnTableroPrueba);
        buttonsPanel.add(btnConfigurarPartida);
        buttonsPanel.add(btnUnirsePartida);
        buttonsPanel.add(btnSalir);

        main.add(buttonsPanel, BorderLayout.CENTER);

        setContentPane(main);
    }

    // --- MÉTODOS PARA AGREGAR LISTENERS ---

    public void addConfigurarPartidaListener(ActionListener listener) {
        btnConfigurarPartida.addActionListener(listener);
    }

    // CORREGIDO: Solo añade el listener, no abre la ventana
    public void addTableroPrueba(ActionListener listener) {
        BtnTableroPrueba.addActionListener(listener);
    }

    public void addUnirsePartidaListener(ActionListener listener) {
        btnUnirsePartida.addActionListener(listener);
    }

    public void addSalirListener(ActionListener listener) {
        btnSalir.addActionListener(listener);
    }

    // --- GETTERS (NUEVO: Necesario para el Controller) ---
    
    public JButton getBtnTableroPrueba() {
        return BtnTableroPrueba;
    }
    
    public JButton getBtnSalir() {
        return btnSalir;
    }

    // --- UTILIDADES ---

    public void mostrarMensaje(String message) {
        JOptionPane.showMessageDialog(this, message);
    }
}