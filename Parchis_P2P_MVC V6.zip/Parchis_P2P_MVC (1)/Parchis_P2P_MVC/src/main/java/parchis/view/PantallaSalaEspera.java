/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parchis.view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 *
 * @author zarex
 */
public class PantallaSalaEspera extends JFrame {

    private JTextField txtGameId;
    private JButton btnCopiarId;
    private DefaultListModel<String> jugadoresModel;
    private JList<String> listaJugadores;
    private JButton btnIniciar;
    private JButton btnSalirSala;

    public PantallaSalaEspera() {
        setTitle("Sala de espera - Parchis");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        buildUi();
        pack();
        setSize(500, 350);
        setLocationRelativeTo(null);
    }

    private void buildUi() {
        JPanel main = new JPanel(new BorderLayout(10, 10));
        main.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel title = new JLabel("Sala de espera", SwingConstants.CENTER);
        title.setFont(title.getFont().deriveFont(Font.BOLD, 20f));

        JPanel top = new JPanel(new BorderLayout(5, 0));
        top.add(new JLabel("Id de partida:"), BorderLayout.WEST);

        txtGameId = new JTextField();
        txtGameId.setEditable(false);
        top.add(txtGameId, BorderLayout.CENTER);

        btnCopiarId = new JButton("Copiar id");
        top.add(btnCopiarId, BorderLayout.EAST);

        JPanel header = new JPanel(new BorderLayout(5, 5));
        header.add(title, BorderLayout.NORTH);
        header.add(top, BorderLayout.SOUTH);

        main.add(header, BorderLayout.NORTH);

        JPanel center = new JPanel(new BorderLayout(5, 5));
        center.setBorder(BorderFactory.createTitledBorder("Jugadores conectados"));

        jugadoresModel = new DefaultListModel<>();
        listaJugadores = new JList<>(jugadoresModel);
        JScrollPane scroll = new JScrollPane(listaJugadores);

        center.add(scroll, BorderLayout.CENTER);
        main.add(center, BorderLayout.CENTER);

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnIniciar = new JButton("Iniciar partida");
        btnSalirSala = new JButton("Salir de la sala");
        bottom.add(btnSalirSala);
        bottom.add(btnIniciar);

        main.add(bottom, BorderLayout.SOUTH);

        setContentPane(main);
    }

    public void setGameId(String id) {
        txtGameId.setText(id != null ? id : "");
    }

    public String getGameId() {
        return txtGameId.getText().trim();
    }

    public void actualizarJugadores(List<String> nombres) {
        jugadoresModel.clear();
        if (nombres != null) {
            for (String n : nombres) {
                jugadoresModel.addElement(n);
            }
        }
    }

    public void addCopiarIdListener(ActionListener listener) {
        btnCopiarId.addActionListener(listener);
    }

    public void addIniciarListener(ActionListener listener) {
        btnIniciar.addActionListener(listener);
    }

    public void addSalirSalaListener(ActionListener listener) {
        btnSalirSala.addActionListener(listener);
    
    }

    public void setIniciarHabilitado(boolean enabled) {
        btnIniciar.setEnabled(enabled);
    }

    public void showMessage(String message) {
        JOptionPane.showMessageDialog(this, message);
    }

    public void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error",
                JOptionPane.ERROR_MESSAGE);
    }
}
