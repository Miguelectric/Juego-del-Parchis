package parchis.view;

import parchis.model.Jugador;
import parchis.model.Partida;
import javax.swing.*;
import java.awt.*;

public class FrmGame extends JFrame {
    
    
    private JLabel lblEstado;
    private JButton btnDado;

    public FrmGame(Partida partida, Jugador local) {
        setTitle("Parchís P2P (Gráfico) - Jugador: " + local.getName());
        setSize(800, 850);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel top = new JPanel();
        lblEstado = new JLabel("Esperando inicio...");
        lblEstado.setFont(new Font("Arial", Font.BOLD, 16));
        btnDado = new JButton("TIRAR DADO");
        btnDado.setEnabled(false); 

        top.add(lblEstado);
        top.add(btnDado);
        add(top, BorderLayout.NORTH);

     
    }

    public void setEstado(String texto) {
        lblEstado.setText(texto);
    }

    public JButton getBtnDado() {
        return btnDado;
    }
    
   
}