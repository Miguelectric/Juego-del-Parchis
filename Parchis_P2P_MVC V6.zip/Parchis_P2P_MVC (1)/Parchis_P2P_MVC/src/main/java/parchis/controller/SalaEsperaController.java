package parchis.controller;

import java.util.List;
import java.util.stream.Collectors;
import javax.swing.SwingUtilities;
import parchis.model.Jugador;
import parchis.model.Partida;
import parchis.network.PeerNetwork;
import parchis.view.PantallaSalaEspera;
import parchis.view.PantallaInicio;
// Importamos la NUEVA vista
import parchis.view.TableroParchis; 

public class SalaEsperaController {

    private final PantallaSalaEspera view;
    private final PeerNetwork network;
    private final Partida partida;
    private final Jugador localPlayer;
    private final boolean soyHost;
    private final String sharedGameId;

    public SalaEsperaController(PantallaSalaEspera view,
                                PeerNetwork network,
                                Partida partida,
                                Jugador localPlayer,
                                boolean soyHost,
                                String sharedGameId) {
        this.view = view;
        this.network = network;
        this.partida = partida;
        this.localPlayer = localPlayer;
        this.soyHost = soyHost;
        this.sharedGameId = sharedGameId;
        init();
    }

    private void init() {
        view.setGameId(sharedGameId);
        refrescarListaJugadores();
        view.setIniciarHabilitado(soyHost);

        view.addCopiarIdListener(e -> onCopiarId());
        view.addIniciarListener(e -> onIniciarPartida());
        view.addSalirSalaListener(e -> onSalirSala());

        if (soyHost) {
            network.setPlayersUpdateListener(nombres -> 
                SwingUtilities.invokeLater(() -> view.actualizarJugadores(nombres)));
        } else {
            // CLIENTE: Escucha si el host inicia el juego
            network.setGameMessageListener(msg -> {
                if(msg.contains("GAME|START")) {
                    SwingUtilities.invokeLater(this::iniciarJuegoGrafico);
                }
            });
        }
    }

    private void refrescarListaJugadores() {
        List<String> nombres = partida.getJugadores().stream()
                .map(Jugador::getName)
                .collect(Collectors.toList());
        view.actualizarJugadores(nombres);
    }

    private void onCopiarId() {
        String id = view.getGameId();
        if (id == null || id.isEmpty()) {
            view.showError("No hay id de partida para copiar.");
            return;
        }
        java.awt.datatransfer.StringSelection selection
                = new java.awt.datatransfer.StringSelection(id);
        java.awt.Toolkit.getDefaultToolkit().getSystemClipboard()
                .setContents(selection, selection);
        view.showMessage("Id copiado al portapapeles.");
    }

    private void onIniciarPartida() {
        if (!soyHost) {
            view.showError("Solo el anfitrion puede iniciar la partida.");
            return;
        }
        
        // Enviar señal de inicio a todos
        network.enviarMensajeJuego("GAME|START");
        
        // Iniciar mi propia interfaz gráfica
        iniciarJuegoGrafico();
    }
    
    private void iniciarJuegoGrafico() {
        view.dispose(); // Cerrar la sala de espera
        
        // --- AQUÍ ESTÁ EL CAMBIO CLAVE ---
        // 1. Creamos la NUEVA vista (la de los JTextFields)
        TableroParchis gameView = new TableroParchis();
        
        // 2. Iniciamos el controlador pasándole esa vista y los datos del juego
        new JuegoController(gameView, network, partida, localPlayer);
        
        // 3. Hacemos visible la ventana
        gameView.setVisible(true);
    }

    private void onSalirSala() {
        view.dispose();
        PantallaInicio inicio = new PantallaInicio();
        new InicioController(inicio, network);
        inicio.setVisible(true);
    }
}