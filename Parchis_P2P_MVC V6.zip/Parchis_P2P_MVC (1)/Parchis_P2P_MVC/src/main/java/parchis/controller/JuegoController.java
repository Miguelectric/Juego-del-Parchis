package parchis.controller;

import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import parchis.model.Ficha;
import parchis.model.Jugador;
import parchis.model.Partida;
import parchis.network.PeerNetwork;
import parchis.view.TableroParchis;

public class JuegoController {

    private TableroParchis view;
    private PeerNetwork network;
    private Partida partida;
    private Jugador localPlayer;

    private int turnoIndex = 0; 
    private int valorDadoActual = 0;
    private int contadorSeises = 0;
    private boolean dadoLanzado = false;

    public JuegoController(TableroParchis view, PeerNetwork network, Partida partida, Jugador localPlayer) {
        this.view = view;
        this.network = network;
        this.partida = partida;
        this.localPlayer = localPlayer;
        init();
    }

    private void init() {
        network.setGameMessageListener(this::procesarMensajeRed);
        view.getBtnAccion().addActionListener(this::onBotonAccion);
        actualizarTableroCompleto();
        verificarTurno();
    }

    private void onBotonAccion(ActionEvent e) {
        if (!dadoLanzado) {
            tirarDado();
        } else {
            intentarMover();
        }
    }
    
    // Método auxiliar para volver al inicio
    private void volverAlMenuPrincipal() {
        view.dispose(); // Cierra el tablero
        
        // Abre la pantalla de inicio
        parchis.view.PantallaInicio inicio = new parchis.view.PantallaInicio();
        // Necesitamos reiniciar la red o pasar la existente. 
        // Para simplificar y evitar errores de sockets viejos, pasamos la misma red.
        new parchis.controller.InicioController(inicio, network); 
        inicio.setVisible(true);
    }
    
    private void tirarDado() {
        valorDadoActual = (int)(Math.random() * 6) + 1;
        view.setEstado(localPlayer.getAlias() + " | DADO: " + valorDadoActual);
        network.enviarMensajeJuego("GAME|DADO|" + localPlayer.getName() + "|" + valorDadoActual);
        
        view.getBtnAccion().setText("ELEGIR FICHA");
        dadoLanzado = true;
        
        if (valorDadoActual == 6) {
            contadorSeises++;
            if (contadorSeises == 3) {
                JOptionPane.showMessageDialog(view, "¡Tres 6 seguidos! Pierdes turno.");
                pasarTurno();
            }
        } else {
            contadorSeises = 0;
        }
    }

   private void intentarMover() {
        java.util.List<Ficha> fichasMovibles = new java.util.ArrayList<>();
        java.util.List<String> opciones = new java.util.ArrayList<>();

        // 1. REGLA DEL 5 (SALIR DE CASA)
        if (valorDadoActual == 5) {
            for (Ficha f : localPlayer.getFichas()) {
                if (f.isEnCasa()) {
                    fichasMovibles.add(f);
                    opciones.add("SACAR Ficha " + (f.getId() + 1));
                }
            }
        }

        // 2. MOVIMIENTO NORMAL (FILTRADO ESTRICTO)
        for (Ficha f : localPlayer.getFichas()) {
            
            // DESCARTAR SI: Está en casa o Ya terminó
            if (f.isEnCasa() || f.isEnMeta()) continue;

            // --- VALIDACIÓN PREVIA: ¿PUEDE MOVERSE CON ESTE DADO? ---
            boolean movimientoValido = true;
            String estado = "En Tablero";

            // A) SI ESTÁ EN PASILLO (META)
            if (f.getPosicion() >= 100) {
                estado = "En Pasillo";
                int base = (f.getPosicion() / 100) * 100;
                int pasoActual = f.getPosicion() - base; // 0 a 4
                int pasoFuturo = pasoActual + valorDadoActual;

                // REGLA 1: Si se pasa del 4 (Centro), se INHABILITA
                if (pasoFuturo > 4) {
                    movimientoValido = false; 
                }
                
                // REGLA 2: Si la casilla destino está ocupada por mí (Bloqueo total)
                // (Nota: Si quieres permitir el "retroceso", quita este if, 
                // pero si quieres que se inhabilite si no puede avanzar, déjalo).
                int posFuturaAbsoluta = base + pasoFuturo;
                if (movimientoValido && isCasillaOcupadaPorMi(posFuturaAbsoluta, f)) {
                    // Si está ocupada y no cabe, inhabilitada
                    movimientoValido = false;
                }
            }
            // B) SI ESTÁ EN TABLERO NORMAL
            else {
                // Aquí casi siempre es válido salvo bloqueos especiales
            }

            // Si pasó todas las pruebas, la agregamos a la lista
            if (movimientoValido) {
                fichasMovibles.add(f);
                opciones.add("MOVER Ficha " + (f.getId() + 1) + " (" + estado + ")");
            }
        }

        // 3. SI NO HAY MOVIMIENTOS POSIBLES
        if (fichasMovibles.isEmpty()) {
            if (localPlayer.verificarVictoria()) {
                javax.swing.JOptionPane.showMessageDialog(view, "¡FELICIDADES! ¡JUEGO COMPLETADO!");
            } else {
                javax.swing.JOptionPane.showMessageDialog(view, "No puedes mover ninguna ficha con un " + valorDadoActual);
                pasarTurno();
            }
            return;
        }

        // 4. MOSTRAR MENÚ
        int elegida = javax.swing.JOptionPane.showOptionDialog(view, 
                "Sacaste un " + valorDadoActual + ". Elige opción válida:", 
                "Tu Turno", 
                javax.swing.JOptionPane.DEFAULT_OPTION, 
                javax.swing.JOptionPane.QUESTION_MESSAGE, 
                null, 
                opciones.toArray(), 
                opciones.get(0));

        if (elegida >= 0) {
            ejecutarMovimiento(localPlayer, fichasMovibles.get(elegida), valorDadoActual);
        }
    }

    // --- LÓGICA MAESTRA DE MOVIMIENTO Y PUNTOS ---
   // LÓGICA PRINCIPAL DE MOVIMIENTO
    private void ejecutarMovimiento(Jugador jugador, Ficha ficha, int dado) {
        int posAnterior = ficha.getPosicion();
        
        // 1. Limpiar visualmente
        if(!jugador.isEliminado()) {
            view.limpiarCasilla(posAnterior);
        }

        int posSimulada = posAnterior;
        int entradaPasillo = (jugador.getCasillaSalida() - 2 + 52) % 52;

        if (dado == 5 && ficha.isEnCasa()) {
            ficha.salirDeCasa(jugador.getCasillaSalida());
            posSimulada = ficha.getPosicion();
        } 
        else {
            for (int i = 0; i < dado; i++) {
                // Lógica Pasillo
                if (posSimulada >= 100) {
                    int base = (posSimulada / 100) * 100;
                    int pasoActual = posSimulada - base;
                    if (pasoActual < 4) {
                        posSimulada++;
                        
                        // SUMAR PUNTOS POR AVANZAR EN META
                        jugador.sumarPuntos(10); 
                        
                        // --- CHEQUEO RÁPIDO DE VICTORIA POR PUNTOS ---
                        if (checkVictoriaPorPuntos(jugador)) return; 
                    }
                } 
                // Lógica Entrada
                else if (posSimulada == entradaPasillo) {
                    posSimulada = obtenerBasePasillo(jugador); 
                    jugador.sumarPuntos(10);
                    if (checkVictoriaPorPuntos(jugador)) return;
                } 
                // Lógica Normal
                else {
                    posSimulada++;
                    if (posSimulada >= 52) posSimulada = 0;
                }
            }

            // Anti-apilamiento en pasillo
            if (posSimulada >= 100) {
                while (isCasillaOcupadaPorMi(posSimulada, ficha) && posSimulada > posAnterior) {
                    posSimulada--; 
                    view.setEstado("Casilla ocupada. Retrocedes.");
                }
            }

            if (!ficha.isEnMeta()) {
                ficha.salirDeCasa(posSimulada);
            }
        }
        
        // --- LÓGICA DE CORONACIÓN ---
        if (posSimulada >= 100 && (posSimulada % 100) == 4) {
             if (!ficha.isEnMeta()) {
                 ficha.coronarMeta(); 
                 jugador.sumarPuntos(50); // Bono grande
                 JOptionPane.showMessageDialog(view, "¡FICHA CORONADA! +50 Pts");
                 
                 // --- CHEQUEO FINAL DE VICTORIA POR PUNTOS ---
                 if (checkVictoriaPorPuntos(jugador)) return;
             }
        }

        verificarColision(ficha);

        // Enviar a red
        String msg = "GAME|MOVE|" + jugador.getName() + "|" + ficha.getId() + "|" + ficha.getPosicion() + "|" + jugador.getPuntos();
        network.enviarMensajeJuego(msg);

        actualizarTableroCompleto();

        // Regla del 6
        if (dado == 6 && contadorSeises < 3) {
            view.setEstado("¡Sacaste 6! ¡REPITES!");
            view.getBtnAccion().setText("TIRAR DADO");
            dadoLanzado = false;
        } else {
            view.getBtnAccion().setText("ESPERANDO...");
            view.getBtnAccion().setEnabled(false);
            pasarTurno();
        }
    }

    // --- NUEVO MÉTODO AUXILIAR PARA VERIFICAR LOS 180 PUNTOS ---
    private boolean checkVictoriaPorPuntos(Jugador j) {
        if (j.getPuntos() >= 180) {
            // Actualizar visualmente antes de mostrar el mensaje
            view.actualizarVidas(partida.getJugadores()); 
            
            JOptionPane.showMessageDialog(view, 
                "¡🏆 VICTORIA POR PUNTOS! 🏆\n" +
                "El jugador " + j.getName() + " ha llegado a " + j.getPuntos() + " puntos.\n" +
                "¡Fin del juego!");
                
            network.enviarMensajeJuego("GAME|WIN|" + j.getName());
            volverAlMenuPrincipal();
            return true; // Indica que el juego terminó
        }
        return false; // El juego sigue
    }

    // Método auxiliar necesario para saber a qué pasillo ir (100, 200, 300, 400)
    private int obtenerBasePasillo(Jugador j) {
        if (j.getColorName().equals("BLUE")) return 100;
        if (j.getColorName().equals("RED")) return 200;
        if (j.getColorName().equals("GREEN")) return 300;
        if (j.getColorName().equals("YELLOW")) return 400;
        return 0;
    }
    
    
    private void verificarColision(Ficha miFicha) {
        for (Jugador enemigo : partida.getJugadores()) {
            if (enemigo == localPlayer) continue;
            for (Ficha fEnemiga : enemigo.getFichas()) {
                if (!fEnemiga.isEnCasa() && fEnemiga.getPosicion() < 100 && fEnemiga.getPosicion() == miFicha.getPosicion()) {
                    fEnemiga.regresarACasa();
                    enemigo.perderVida();
                    JOptionPane.showMessageDialog(view, "¡COMISTE A " + enemigo.getAlias() + "!");
                    network.enviarMensajeJuego("GAME|KILL|" + enemigo.getName() + "|" + fEnemiga.getId());
                }
            }
        }
    }

    private void pasarTurno() {
        dadoLanzado = false;
        contadorSeises = 0;
        int intentos = 0;
        do {
            turnoIndex = (turnoIndex + 1) % partida.getJugadores().size();
            intentos++;
        } while (partida.getJugadores().get(turnoIndex).isEliminado() && intentos < 4);
        
        String next = partida.getJugadores().get(turnoIndex).getName();
        network.enviarMensajeJuego("GAME|TURN|" + next);
        verificarTurno();
    }

   private void procesarMensajeRed(String mensaje) {
        // Usamos invokeLater para que los cambios visuales no congelen la interfaz
        javax.swing.SwingUtilities.invokeLater(() -> {
            
            String[] parts = mensaje.split("\\|");
            if (parts.length < 2) return; // Validación básica
            
            String tipo = parts[1];

            switch (tipo) {
                // 1. INICIO DE PARTIDA
                case "START": 
                    view.setEstado("¡Juego Iniciado!"); 
                    break;
                    
                // 2. ALGUIEN TIRÓ EL DADO
                case "DADO":  
                    view.setEstado(parts[2] + " sacó un " + parts[3]); 
                    break;
                
                // 3. ALGUIEN MOVIÓ UNA FICHA
                case "MOVE":
                    // Formato: GAME|MOVE|NombreJugador|IdFicha|NuevaPosicion|Puntos
                    String nombre = parts[2];
                    int idFicha = Integer.parseInt(parts[3]);
                    int posNueva = Integer.parseInt(parts[4]);
                    
                    // Buscamos al jugador remoto para actualizar su ficha en MI pantalla
                    for(parchis.model.Jugador j : partida.getJugadores()) {
                        if(j.getName().equals(nombre)) {
                            parchis.model.Ficha f = j.getFichas().get(idFicha);
                            
                            // Forzamos la posición visualmente
                            // (Usamos salirDeCasa como 'teletransporte' porque funciona bien para esto)
                            f.salirDeCasa(posNueva);
                            
                            // Si el mensaje trae puntos, sincronizamos
                            if(parts.length > 5) {
                                int puntosRivales = Integer.parseInt(parts[5]);
                                int diferencia = puntosRivales - j.getPuntos();
                                if(diferencia > 0) j.sumarPuntos(diferencia);
                            }
                        }
                    }
                    actualizarTableroCompleto(); // Repintar todo
                    break;
                    
                // 4. ALGUIEN MURIÓ (COMIDO)
                case "KILL":
                    String victima = parts[2];
                    int idMuerto = Integer.parseInt(parts[3]);
                    
                    for(parchis.model.Jugador j : partida.getJugadores()) {
                        if(j.getName().equals(victima)) {
                            // Regresar ficha a casa y quitar vida
                            j.getFichas().get(idMuerto).regresarACasa();
                            j.perderVida(); 
                        }
                    }
                    actualizarTableroCompleto();
                    break;
                
                // 5. ALGUIEN GANÓ EL JUEGO (GAME OVER PARA MÍ)
                case "WIN":
                    String nombreGanador = parts[2];
                    javax.swing.JOptionPane.showMessageDialog(view, 
                        "❌ GAME OVER ❌\n" +
                        "El jugador " + nombreGanador + " ha ganado la partida.\n" +
                        "Serás redirigido al menú principal.");
                    
                    volverAlMenuPrincipal(); // Cerrar y salir
                    break;
                    
                // 6. CAMBIO DE TURNO
                case "TURN": 
                    actualizarTurnoPorNombre(parts[2]); 
                    break;
            }
        });
    }

   private void actualizarTableroCompleto() {
        // 1. LIMPIEZA TOTAL (Tablero + Pasillos)
        // Esto evita que queden "fichas fantasma" de turnos anteriores
        view.limpiarTodo();
        
        // 2. Actualizar marcadores de vida/puntos
        view.actualizarVidas(partida.getJugadores());
        
        // 3. Pintar SOLO las 4 fichas reales de cada jugador
        for (Jugador j : partida.getJugadores()) {
            for(Ficha f : j.getFichas()) {
                // Solo se pintan si están activas en el tablero
                if(!f.isEnCasa()) {
                    view.pintarFicha(f.getPosicion(), j.getColorObj(), j.getAlias());
                }
            }
        }
    }
    private void actualizarTurnoPorNombre(String nombre) {
        for(int i=0; i<partida.getJugadores().size(); i++) {
            if(partida.getJugadores().get(i).getName().equals(nombre)) { turnoIndex = i; break; }
        }
        verificarTurno();
    }

    private void verificarTurno() {
        Jugador turno = partida.getJugadores().get(turnoIndex);
        if(turno.isEliminado()) { if(turno == localPlayer) pasarTurno(); return; }
        
        if (turno == localPlayer) {
            view.setEstado("TU TURNO");
            view.getBtnAccion().setEnabled(true);
            if(!dadoLanzado) view.getBtnAccion().setText("TIRAR DADO");
        } else {
            view.setEstado("Turno de: " + turno.getName());
            view.getBtnAccion().setEnabled(false);
            view.getBtnAccion().setText("ESPERANDO...");
        }
    }
   private boolean isCasillaOcupadaPorMi(int pos, Ficha miFichaActual) {
        for (Ficha f : localPlayer.getFichas()) {
            // CONDICIÓN:
            // 1. No soy yo mismo (la ficha que se mueve).
            // 2. No está en casa.
            // 3. Está en la posición que quiero ocupar.
            // (IMPORTANTE: Quitamos !f.isEnMeta() para que las coronadas también estorben)
            
            if (f.getId() != miFichaActual.getId() && 
                !f.isEnCasa() && 
                f.getPosicion() == pos) {
                return true; // Está ocupada (sea por una ficha activa o una coronada)
            }
        }
        return false;
    }
}