package parchis.controller;

import java.io.IOException;
import parchis.model.Jugador;
import parchis.model.Partida;
import parchis.network.PeerNetwork;
import parchis.view.PantallaInicio;
import parchis.view.PantallaSalaEspera;
import parchis.view.PantallaUnirsePartida;

public class UnirsePartidaController {

    private final PantallaUnirsePartida view;
    private final PeerNetwork network;

    public UnirsePartidaController(PantallaUnirsePartida view, PeerNetwork network) {
        this.view = view;
        this.network = network;
        init();
    }

    private void init() {
        view.addUnirseListener(e -> onUnirse());
        view.addCancelarListener(e -> onCancelar());
    }

    private void onUnirse() {
        String name = view.getPlayerName();
        String sharedGameId = view.getGameId();

        if (name.isEmpty() || sharedGameId.isEmpty()) {
            view.showError("Nombre e id de partida son obligatorios.");
            return;
        }

        try {
            // El PeerNetwork ya se encarga de asignar el color correcto (P2, P3, etc.)
            PeerNetwork.JoinResult result = network.joinGameUsingId(sharedGameId, name);
            Partida partida = result.getPartida();
            Jugador jugadorLocal = result.getJugadorLocal();

            PantallaSalaEspera sala = new PantallaSalaEspera();
            // Pasamos 'false' porque somos clientes
            new SalaEsperaController(sala, network, partida, jugadorLocal, false, sharedGameId);
            sala.setVisible(true);

            view.dispose();
        } catch (IllegalArgumentException | IllegalStateException ex) {
            view.showError(ex.getMessage());
        } catch (IOException ex) {
            view.showError("No se pudo conectar con el host: " + ex.getMessage());
        }
    }

    private void onCancelar() {
        view.dispose();
        PantallaInicio inicio = new PantallaInicio();
        new InicioController(inicio, network);
        inicio.setVisible(true);
    }
}