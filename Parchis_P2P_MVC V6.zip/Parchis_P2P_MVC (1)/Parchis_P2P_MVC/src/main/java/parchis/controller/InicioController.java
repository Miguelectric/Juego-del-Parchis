package parchis.controller;

import parchis.model.ConfiguracionPartida;
import parchis.model.Jugador;
import parchis.model.Partida;
import parchis.network.PeerNetwork;
import parchis.view.FrmGame;
import parchis.view.FrmTablero;
import parchis.view.PantallaConfigurarPartida;
import parchis.view.PantallaInicio;
import parchis.view.PantallaUnirsePartida;

public class InicioController {

    private final PantallaInicio view;
    private final PeerNetwork network;

    public InicioController(PantallaInicio view, PeerNetwork network) {
        this.view = view;
        this.network = network;
        init();
    }

    private void init() {
        view.addConfigurarPartidaListener(e -> onConfigurarPartida());
        view.addUnirsePartidaListener(e -> onUnirsePartida());
        view.addSalirListener(e -> System.exit(0));
        view.addTableroPrueba(e -> onTableroPrueba());
    }

    private void onConfigurarPartida() {
        PantallaConfigurarPartida configView = new PantallaConfigurarPartida();
        new ConfigurarPartidaController(configView, network);
        configView.setVisible(true);
        view.dispose();
    }

    private void onUnirsePartida() {
        PantallaUnirsePartida unirseView = new PantallaUnirsePartida();
        new UnirsePartidaController(unirseView, network);
        unirseView.setVisible(true);
        view.dispose();
    }
    
    private void onTableroPrueba() {
        // DATOS FALSOS PARA TESTEAR LA VISTA
        ConfiguracionPartida config = new ConfiguracionPartida(4, 30, true, true);
        Partida testPartida = new Partida("TEST", config, "LOCAL");
        Jugador yo = new Jugador("local", "Yo (Test)", "RED");
        testPartida.addJugador(yo);
        testPartida.addJugador(new Jugador("cpu1", "Rival 1", "GREEN"));
        
        FrmTablero tabla = new FrmTablero(testPartida, yo);
        // NO iniciamos el Controller porque no hay red, solo mostramos la vista
        tabla.setVisible(true);
    }
}