/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parchis.controller;

import parchis.model.ConfiguracionPartida;
import parchis.model.Jugador;
import parchis.model.Partida;
import parchis.network.PeerNetwork;
import parchis.view.PantallaConfigurarPartida;
import parchis.view.PantallaSalaEspera;

import java.util.UUID;

/**
 *
 * @author PC
 */
public class ConfigurarPartidaController {

    private final PantallaConfigurarPartida view;
    private final PeerNetwork network;
    private Partida partida;
    private Jugador localPlayer;

    public ConfigurarPartidaController(PantallaConfigurarPartida view, PeerNetwork network) {
        this.view = view;
        this.network = network;
        init();
    }

    private void init() {
        view.addCreateMatchListener(e -> onCreateMatch());
    }

   private void onCreateMatch() {
        String playerName = view.getPlayerName();
        if (playerName.isEmpty()) {
            view.showError("Escribe un nombre para el jugador.");
            return;
        }

        int maxPlayers = view.getMaxPlayers();
        int turnTime = view.getTurnTimeSeconds();
        boolean eatOnExit = view.isEatOnExitEnabled();
        boolean exitWithFive = view.isExitWithFiveEnabled();

        ConfiguracionPartida config = new ConfiguracionPartida(
                maxPlayers,
                turnTime,
                eatOnExit,
                exitWithFive
        );

        String baseGameId = UUID.randomUUID().toString();
        partida = new Partida(baseGameId, config, network.getLocalId());

        // --- CORRECCIÓN: El Host siempre es BLUE (P1) ---
        localPlayer = new Jugador(network.getLocalId(), playerName, "BLUE");
        partida.addJugador(localPlayer);

        network.setHostedGame(partida);
        network.anunciarPartida(partida);

        String sharedGameId = network.crearIdCompartible(baseGameId);

        PantallaSalaEspera sala = new PantallaSalaEspera();
        new SalaEsperaController(sala, network, partida, localPlayer, true, sharedGameId);
        sala.setVisible(true);

        view.dispose();
    }

    public Partida getPartida() {
        return partida;
    }

    public Jugador getLocalPlayer() {
        return localPlayer;
    }
}
